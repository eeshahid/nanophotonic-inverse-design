"""
forward_model/train_fn.py
===========================
Training loop + evaluation (raw and Savitzky-Golay post-processed) for the image->spectrum
forward model. Ported/simplified from the reference forward-model project's train_fn.py
(mxene_forward/my_code/train_fn.py) -- only Savitzky-Golay post-processing is kept (the
reference also supports several other inference-time smoothing filters for comparison,
not needed here).

Note the (spectra, images) unpacking order below matches THIS project's ImageSpectrumDataset
(../build_data.py), which returns (spectrum, image) -- the opposite order from the reference
project's dataset.
"""
import copy
import os
import time

import numpy as np
import torch
import torch.nn as nn
from scipy.signal import savgol_filter


def savgol_smooth(predictions: np.ndarray, window_length: int, polyorder: int) -> np.ndarray:
    """Savitzky-Golay smoothing along the spectrum axis (axis=1). predictions: (N, L)."""
    if window_length % 2 == 0:
        raise ValueError(f"window_length must be odd, got {window_length}")
    if polyorder >= window_length:
        raise ValueError(f"polyorder must be < window_length (got {polyorder} >= {window_length})")
    return savgol_filter(predictions, window_length=window_length, polyorder=polyorder, axis=1)


def regression_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> dict:
    mse = float(np.mean((y_true - y_pred) ** 2))
    rmse = float(np.sqrt(mse))
    ss_res = float(np.sum((y_true - y_pred) ** 2))
    ss_tot = float(np.sum((y_true - y_true.mean()) ** 2))
    r2 = float(1 - ss_res / ss_tot) if ss_tot > 0 else float("nan")
    max_val = float(np.max(y_true))
    psnr = float(20 * np.log10(max_val / np.sqrt(mse))) if mse > 0 else float("inf")
    mae = float(np.mean(np.abs(y_true - y_pred)))
    return {"mse": mse, "rmse": rmse, "r2": r2, "psnr": psnr, "mae": mae}


@torch.no_grad()
def predict_model(model, loader, device):
    model.eval()
    predictions, ground_truth = [], []
    for spectra, images in loader:
        images = images.to(device)
        outputs = model(images)
        predictions.append(outputs.detach().cpu().numpy())
        ground_truth.append(spectra.numpy())
    return np.vstack(predictions), np.vstack(ground_truth)


def run_one_epoch(model, loader, criterion, optimizer, device, train: bool):
    model.train() if train else model.eval()
    total_loss = 0.0
    preds, targets = [], []
    context = torch.enable_grad() if train else torch.no_grad()
    with context:
        for spectra, images in loader:
            images = images.to(device)
            spectra = spectra.to(device)
            if train:
                optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, spectra)
            if train:
                loss.backward()
                optimizer.step()
            total_loss += loss.item()
            preds.append(outputs.detach().cpu().numpy())
            targets.append(spectra.detach().cpu().numpy())
    avg_loss = total_loss / max(1, len(loader))
    metrics = regression_metrics(np.vstack(targets), np.vstack(preds))
    metrics["loss"] = float(avg_loss)
    return metrics


def train_model(model, train_loader, val_loader, device, logger, checkpoint_dir,
                 num_epochs=100, patience=30, lr=1e-3, weight_decay=0.0):
    """Plain MSE + Adam training loop with early stopping on val loss (matches the reference
    project's train_fn.py:train_model). Saves `latest.pth` every epoch and `best.pth` on
    improvement, both as raw state_dicts -- the same convention ../train_fn.py uses, and
    what ../build_data.py:load_forward_model expects (plain `torch.load` + `load_state_dict`,
    no wrapping dict)."""
    os.makedirs(checkpoint_dir, exist_ok=True)
    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)

    best_val_loss = float("inf")
    best_epoch = -1
    best_state = None
    epochs_no_improve = 0
    training_start = time.time()

    for epoch in range(num_epochs):
        train_metrics = run_one_epoch(model, train_loader, criterion, optimizer, device, train=True)
        val_metrics = run_one_epoch(model, val_loader, criterion, optimizer, device, train=False)

        logger.info(
            f"Epoch [{epoch + 1}/{num_epochs}] "
            f"Train Loss: {train_metrics['loss']:.6f} RMSE: {train_metrics['rmse']:.6f} | "
            f"Val Loss: {val_metrics['loss']:.6f} RMSE: {val_metrics['rmse']:.6f} R2: {val_metrics['r2']:.6f}"
        )

        torch.save(model.state_dict(), os.path.join(checkpoint_dir, "latest.pth"))

        if val_metrics["loss"] < best_val_loss:
            best_val_loss = val_metrics["loss"]
            best_epoch = epoch + 1
            best_state = copy.deepcopy(model.state_dict())
            epochs_no_improve = 0
            torch.save(best_state, os.path.join(checkpoint_dir, "best.pth"))
            logger.info(f"  Validation loss improved. Saving best model to {checkpoint_dir}/best.pth")
        else:
            epochs_no_improve += 1
            logger.info(f"  Validation loss did not improve for {epochs_no_improve} epochs (patience={patience}).")
            if epochs_no_improve >= patience:
                logger.info(f"  Early stopping triggered after {epoch + 1} epochs.")
                break

    if best_state is not None:
        model.load_state_dict(best_state)

    return {
        "model": model, "best_val_loss": best_val_loss, "best_epoch": best_epoch,
        "training_time_sec": time.time() - training_start,
    }


@torch.no_grad()
def evaluate_model(model, test_loader, device, apply_savgol=False, savgol_window=11, savgol_polyorder=2):
    predictions, ground_truth = predict_model(model, test_loader, device)
    if apply_savgol:
        predictions = savgol_smooth(predictions, window_length=savgol_window, polyorder=savgol_polyorder)
    metrics = regression_metrics(ground_truth, predictions)
    metrics["apply_savgol"] = bool(apply_savgol)
    metrics["savgol_window"] = savgol_window if apply_savgol else None
    metrics["savgol_polyorder"] = savgol_polyorder if apply_savgol else None
    return metrics

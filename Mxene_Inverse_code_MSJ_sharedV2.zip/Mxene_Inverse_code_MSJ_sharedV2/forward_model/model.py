"""
forward_model/model.py
========================
Image -> spectrum forward (simulator) model: MobileNetV2 backbone + MCSR (the two extra
Conv1d "refinement" layers below the spectrum head -- conv1d1: 1->5 channels, conv1d: 5->1,
kernel_size=5; kept as reference code names it -- exact expansion of "MCSR" not found in
the reference project's code/comments) + an optional Savitzky-Golay layer.

Ported from the reference forward-model project's SpectrumConvStack (see
mxene_forward/my_code/build_model.py), simplified to just the MobileNetV2 backbone --
the reference file supports several other backbones (vgg/resnet/efficientnet/convnext/vit)
not needed here.

Per this project's setup, `use_savgol` is left False during training (see train.py) --
Savitzky-Golay is applied as pure post-processing on the raw predictions at evaluation time
(see train_fn.py:evaluate_model), not baked into the trained weights. SavitzkyGolayLayer is
kept here (matching the reference) in case a baked-in variant is wanted later; train.py
never enables it.
"""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models
from scipy.linalg import pinv


def _replace_first_conv_with_grayscale(module: nn.Module) -> bool:
    """MobileNetV2's first conv expects 3 channels; this project's images are single-channel
    grayscale. Replaces the first Conv2d found with a 1-channel version, averaging the
    pretrained RGB kernel's input-channel weights (if pretrained) so ImageNet weights still
    transfer sensibly."""
    for name, child in module.named_children():
        if isinstance(child, nn.Conv2d):
            new_conv = nn.Conv2d(
                in_channels=1, out_channels=child.out_channels, kernel_size=child.kernel_size,
                stride=child.stride, padding=child.padding, dilation=child.dilation,
                groups=child.groups, bias=(child.bias is not None), padding_mode=child.padding_mode,
            )
            with torch.no_grad():
                if child.weight.shape[1] == 3:
                    new_conv.weight.copy_(child.weight.mean(dim=1, keepdim=True))
                else:
                    new_conv.weight.copy_(child.weight)
                if child.bias is not None:
                    new_conv.bias.copy_(child.bias)
            setattr(module, name, new_conv)
            return True
        if _replace_first_conv_with_grayscale(child):
            return True
    return False


def savgol_kernel(window_length: int, polyorder: int) -> torch.Tensor:
    if window_length % 2 == 0:
        raise ValueError("window_length must be odd")
    half_window = (window_length - 1) // 2
    x = np.arange(-half_window, half_window + 1)
    A = np.vander(x, polyorder + 1)
    coeffs = pinv(A.T @ A) @ A.T
    return torch.tensor(coeffs[0], dtype=torch.float32).view(1, 1, -1)


class SavitzkyGolayLayer(nn.Module):
    """Differentiable Savitzky-Golay smoothing as a fixed (non-trainable) Conv1d. Kept for
    architecture parity with the reference; unused by default (see module docstring)."""

    def __init__(self, window_length: int, polyorder: int):
        super().__init__()
        self.register_buffer("kernel", savgol_kernel(window_length, polyorder))
        self.window_length = window_length

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return F.conv1d(x, self.kernel, padding=self.window_length // 2)


class MobileNetV2Backbone(nn.Module):
    def __init__(self, pretrained: bool = False, dropout: float = 0.2):
        super().__init__()
        weights = models.MobileNet_V2_Weights.DEFAULT if pretrained else None
        self.base_model = models.mobilenet_v2(weights=weights)
        _replace_first_conv_with_grayscale(self.base_model.features)

        in_features = self.base_model.last_channel
        self.base_model.classifier = nn.Sequential(
            nn.Dropout(p=dropout),
            nn.Linear(in_features, in_features),
        )
        self.feature_dim = in_features

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.base_model(x)


class SpectrumForwardModel(nn.Module):
    """MobileNetV2 -> FC -> spectrum head, + MCSR (Conv1d refinement) + optional
    Savitzky-Golay layer (off by default -- see module docstring)."""

    def __init__(self, output_dim: int = 80, pretrained: bool = False, hidden_dim: int = 512,
                 dropout: float = 0.2, use_mcsr: bool = True, use_savgol: bool = False,
                 savgol_window: int = 11, savgol_polyorder: int = 2):
        super().__init__()
        self.backbone = MobileNetV2Backbone(pretrained=pretrained, dropout=dropout)
        self.fc = nn.Linear(self.backbone.feature_dim, hidden_dim)
        self.out_proj = nn.Linear(hidden_dim, output_dim)

        self.use_mcsr = use_mcsr
        if use_mcsr:
            self.conv1d1 = nn.Conv1d(1, 5, kernel_size=5, padding=2)
            self.conv1d = nn.Conv1d(5, 1, kernel_size=5, padding=2)

        self.use_savgol = use_savgol
        if use_savgol:
            self.savgol_layer = SavitzkyGolayLayer(savgol_window, savgol_polyorder)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.backbone(x)
        x = self.fc(x)
        x = self.out_proj(x)
        x = x.unsqueeze(1)  # (B, 1, output_dim), channel dim for the Conv1d layers below

        if self.use_mcsr:
            x = self.conv1d1(x)
            x = self.conv1d(x)
        if self.use_savgol:
            x = self.savgol_layer(x)

        return x.squeeze(1)

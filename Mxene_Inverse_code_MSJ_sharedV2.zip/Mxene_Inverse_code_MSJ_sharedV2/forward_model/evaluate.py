"""
forward_model/evaluate.py
===========================
Standalone re-evaluation of a trained forward-model checkpoint (raw + Savitzky-Golay grid)
on the fixed test split -- mirrors ../evaluate.py's standalone-eval pattern for the inverse
(GAN) pipeline.

Usage
-----
python forward_model/evaluate.py --log_dir forward_model/logs/log_000_20260803_...
"""
import argparse
import os
import sys

import torch
from torch.utils.data import DataLoader, random_split

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from build_data import ImageSpectrumDataset, IMAGE_TRANSFORM  # noqa: E402
from utils import build_logger, load_config, save_config  # noqa: E402

from model import SpectrumForwardModel  # noqa: E402
from train_fn import evaluate_model  # noqa: E402


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Evaluate a trained forward-model checkpoint.")
    parser.add_argument("--log_dir", type=str, required=True,
                         help="Run directory produced by train.py (contains config.json + checkpoints/).")
    parser.add_argument("--checkpoint", choices=["best", "latest"], default="best")
    parser.add_argument("--eval_savgol_windows", type=int, nargs="+", default=[11])
    parser.add_argument("--eval_savgol_polyorders", type=int, nargs="+", default=[2])
    return parser


def _valid_savgol_grid(windows, polyorders):
    return [(w, d) for w in windows for d in polyorders if w % 2 == 1 and d < w]


def main(argv=None):
    args = build_arg_parser().parse_args(argv)
    cfg = load_config(os.path.join(args.log_dir, "config.json"))

    logger = build_logger("forward_eval", os.path.join(args.log_dir, "eval.log"))
    logger.info(f"Evaluating forward model run: {args.log_dir}")

    device = torch.device(cfg.get("device") or ("cuda" if torch.cuda.is_available() else "cpu"))
    logger.info(f"Device: {device}")

    dataset = ImageSpectrumDataset(spectrum_file=cfg["spectrum_file"], image_dir=cfg["data_imag_path"],
                                    transform=IMAGE_TRANSFORM)
    train_size = int(0.8 * len(dataset))
    val_size = int(0.1 * len(dataset))
    test_size = len(dataset) - train_size - val_size
    _, _, test_dataset = random_split(dataset, [train_size, val_size, test_size],
                                       generator=torch.Generator().manual_seed(42))
    test_loader = DataLoader(test_dataset, batch_size=cfg["batch_size"], shuffle=False)

    ckpt_path = os.path.join(args.log_dir, "checkpoints", f"{args.checkpoint}.pth")
    if not os.path.exists(ckpt_path):
        raise FileNotFoundError(f"Checkpoint not found: {ckpt_path}")

    model = SpectrumForwardModel(
        output_dim=cfg["output_dim"], pretrained=False, hidden_dim=cfg["hidden_dim"],
        dropout=cfg["dropout"], use_mcsr=cfg["use_mcsr"], use_savgol=False,
    ).to(device)
    model.load_state_dict(torch.load(ckpt_path, map_location=device))
    model.eval()
    logger.info(f"Loaded checkpoint: {ckpt_path}")

    raw_metrics = evaluate_model(model, test_loader, device, apply_savgol=False)
    logger.info(f"Raw test metrics: {raw_metrics}")

    savgol_results = []
    for w, d in _valid_savgol_grid(args.eval_savgol_windows, args.eval_savgol_polyorders):
        m = evaluate_model(model, test_loader, device, apply_savgol=True, savgol_window=w, savgol_polyorder=d)
        logger.info(f"Savgol(window={w}, polyorder={d}) test metrics: {m}")
        savgol_results.append(m)

    result = {"raw": raw_metrics, "savgol": savgol_results}
    result_path = os.path.join(args.log_dir, f"eval_result_{args.checkpoint}.json")
    save_config(result, result_path)
    logger.info(f"Saved {result_path}")

    return result


if __name__ == "__main__":
    main()

"""
forward_model/train.py
========================
Trains the image -> spectrum forward model on THIS project's dataset -- the same
ImageSpectrumDataset/IMAGE_TRANSFORM (64x64 grayscale) and the same fixed seed=42 80/10/10
split as the inverse pipeline's build_loaders_abl/build_test_loader (see ../build_data.py)
-- so its held-out test set matches the inverse pipeline's exactly. Uses 100% of the
training split (no percentage-subsampling sweep).

Architecture: MobileNetV2 backbone + MCSR (see model.py) -- ported from the reference
forward-model project (mxene_forward/my_code), simplified to just this one configuration
(that project also supports several other backbones/model variants, not needed here).
Savitzky-Golay smoothing is NOT baked into the trained weights; it's applied as
post-processing at evaluation time only (see --eval_savgol_windows/--eval_savgol_polyorders).

Usage
-----
python forward_model/train.py
"""
import argparse
import os
import sys

import torch
from torch.utils.data import DataLoader, random_split

# ../ (inverse/src) for this project's ImageSpectrumDataset/IMAGE_TRANSFORM + logging/config
# utils -- appended (not inserted at 0) so same-named local modules (model.py, train_fn.py)
# still resolve to THIS directory's versions, not ../model.py / ../train_fn.py.
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from build_data import ImageSpectrumDataset, IMAGE_TRANSFORM  # noqa: E402
from utils import build_logger, make_run_dir, save_config, set_seed  # noqa: E402

from model import SpectrumForwardModel  # noqa: E402
from train_fn import evaluate_model, train_model  # noqa: E402


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Train the image->spectrum forward model on this project's data.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    data = parser.add_argument_group("data")
    data.add_argument("--data_imag_path", type=str,
                       default="/home/coe/shahid/mxene/mxene_forward/data_inverse/data_inverse/Data/Images")
    data.add_argument("--spectrum_file", type=str,
                       default="/home/coe/shahid/mxene/mxene_forward/data_inverse/data_inverse/Data/Spectra.csv")
    data.add_argument("--batch_size", type=int, default=32)

    model_g = parser.add_argument_group("model")
    model_g.add_argument("--output_dim", type=int, default=80, help="Number of spectral points.")
    model_g.add_argument("--pretrained", action=argparse.BooleanOptionalAction, default=True,
                          help="Initialize the MobileNetV2 backbone from ImageNet weights "
                               "(default False, matching the reference project).")
    model_g.add_argument("--hidden_dim", type=int, default=512)
    model_g.add_argument("--dropout", type=float, default=0.2)
    model_g.add_argument("--use_mcsr", action=argparse.BooleanOptionalAction, default=True,
                          help="Extra Conv1d refinement layers after the spectrum head (see model.py).")

    eval_g = parser.add_argument_group("evaluation-time smoothing (post-processing only, not trained with)")
    eval_g.add_argument("--eval_savgol_windows", type=int, nargs="+", default=[11])
    eval_g.add_argument("--eval_savgol_polyorders", type=int, nargs="+", default=[2])

    train_g = parser.add_argument_group("training")
    train_g.add_argument("--seed", type=int, default=42, help="Same default as the inverse pipeline.")
    train_g.add_argument("--epochs", type=int, default=100)
    train_g.add_argument("--patience", type=int, default=50)
    train_g.add_argument("--lr", type=float, default=1e-3)
    train_g.add_argument("--weight_decay", type=float, default=0.0)
    train_g.add_argument("--device", type=str, default=None)

    log_g = parser.add_argument_group("logging")
    log_g.add_argument("--log_root", type=str,
                        default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs"),
                        help="Parent directory for per-run log_<NUM>_<TIMESTAMP> dirs -- kept "
                             "separate from ../logs (the inverse GAN pipeline's log root).")

    return parser


def _valid_savgol_grid(windows, polyorders):
    return [(w, d) for w in windows for d in polyorders if w % 2 == 1 and d < w]


def main(argv=None):
    args = build_arg_parser().parse_args(argv)
    cfg = vars(args)

    run_dir = make_run_dir(args.log_root)
    ckpt_dir = os.path.join(run_dir, "checkpoints")
    logger = build_logger("forward_train", os.path.join(run_dir, "train.log"))
    logger.info(f"Run dir: {run_dir}")
    logger.info(f"Config: {cfg}")
    save_config(cfg, os.path.join(run_dir, "config.json"))

    device = torch.device(args.device if args.device else ("cuda" if torch.cuda.is_available() else "cpu"))
    logger.info(f"Device: {device}")
    set_seed(args.seed)

    # ---- data: same dataset/transform/split as the inverse pipeline's fixed test set ----
    dataset = ImageSpectrumDataset(spectrum_file=args.spectrum_file, image_dir=args.data_imag_path,
                                    transform=IMAGE_TRANSFORM)
    train_size = int(0.8 * len(dataset))
    val_size = int(0.1 * len(dataset))
    test_size = len(dataset) - train_size - val_size
    train_dataset, val_dataset, test_dataset = random_split(
        dataset, [train_size, val_size, test_size], generator=torch.Generator().manual_seed(42))
    logger.info(f"train/val/test sizes: {len(train_dataset)}/{len(val_dataset)}/{len(test_dataset)}")

    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=args.batch_size, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=args.batch_size, shuffle=False)

    # ---- model ----
    model = SpectrumForwardModel(
        output_dim=args.output_dim, pretrained=args.pretrained, hidden_dim=args.hidden_dim,
        dropout=args.dropout, use_mcsr=args.use_mcsr, use_savgol=False,
    ).to(device)
    num_params = sum(p.numel() for p in model.parameters())
    logger.info(f"Model: {model.__class__.__name__} | params: {num_params / 1e6:.2f}M")

    # ---- train ----
    train_out = train_model(
        model=model, train_loader=train_loader, val_loader=val_loader, device=device,
        logger=logger, checkpoint_dir=ckpt_dir, num_epochs=args.epochs, patience=args.patience,
        lr=args.lr, weight_decay=args.weight_decay,
    )
    logger.info(f"Training complete. best_epoch={train_out['best_epoch']} "
                f"best_val_loss={train_out['best_val_loss']:.6f}")

    # ---- evaluate: raw + Savitzky-Golay grid on the held-out test split ----
    raw_metrics = evaluate_model(train_out["model"], test_loader, device, apply_savgol=False)
    logger.info(f"Raw test metrics: {raw_metrics}")

    savgol_results = []
    for w, d in _valid_savgol_grid(args.eval_savgol_windows, args.eval_savgol_polyorders):
        m = evaluate_model(train_out["model"], test_loader, device, apply_savgol=True,
                            savgol_window=w, savgol_polyorder=d)
        logger.info(f"Savgol(window={w}, polyorder={d}) test metrics: {m}")
        savgol_results.append(m)

    save_config({"raw": raw_metrics, "savgol": savgol_results}, os.path.join(run_dir, "eval_result.json"))
    logger.info(f"Saved eval_result.json to {run_dir}")

    return run_dir


if __name__ == "__main__":
    main()
